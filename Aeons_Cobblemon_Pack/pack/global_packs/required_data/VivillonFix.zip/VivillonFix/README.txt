Vivillon Fix for Cobblemon 1.6.1
Made By AvivaKitty

Fixes bug where High Plains and Icy Snow Vivillon cannot be evolved from Spewpa.